<script>
    let tipsMsg = {
        least_one    : '<?php echo e(__('luna.least_one'), false); ?>',
        exceeds      : '<?php echo e(__('luna.exceeds'), false); ?>',
        exceeds_limit: '<?php echo e(__('luna.exceeds_limit'), false); ?>',
        mobile_order : '<?php echo e(__('luna.mobile_order'), false); ?>'
    };
</script>
<script src="/assets/luna/layui/layui.js"></script>
<script src="/assets/luna/js/jquery-3.4.1.min.js"></script>
<script src="/assets/luna/main.js"></script>
<script src="/assets/luna/layui/lay/modules/layer.js"></script>
<?php /**PATH /dujiaoka/resources/views/luna/layouts/_script.blade.php ENDPATH**/ ?>