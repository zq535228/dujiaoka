<!-- footer start-->
<footer class="footer p-3">
    <div class="row">
        <div class="col-12 text-center">
            <div class="author">
                Powered by：大叔优选
            </div>
            <div class="custom">
                <?php echo dujiaoka_config_get('footer'); ?>

            </div>
        </div>
    </div>
</footer>
<!-- footer end-->
<?php /**PATH /dujiaoka/resources/views/unicorn/layouts/_footer.blade.php ENDPATH**/ ?>